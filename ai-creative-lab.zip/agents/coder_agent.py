class CoderAgent:
    pass
